# Console App Base

## Source files

### Config.py
### Core.py
### LocaleBase.py
### Machine.py
### Menu.py
### MenuItem.py
